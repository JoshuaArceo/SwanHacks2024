package com.swanhack.swan;

public record Greeting(long id, String content) { }
