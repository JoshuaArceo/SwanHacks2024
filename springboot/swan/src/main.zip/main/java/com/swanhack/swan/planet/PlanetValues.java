package com.swanhack.swan.planet;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Embeddable
public class PlanetValues {

    private int unityId;

    private String planetName;

    @Column(name = "vector", length = 1000) // Store as a comma-separated string
    private String vector; // Serialized form of the list

    private Float percentError;

    // Getters and setters for unityId
    public int getUnityId() {
        return unityId;
    }

    public void setUnityId(int unityId) {
        this.unityId = unityId;
    }

    // Getters and setters for planetName
    public String getPlanetName() {
        return planetName;
    }

    public void setPlanetName(String planetName) {
        this.planetName = planetName;
    }

    // Getters and setters for percentError
    public Float getPercentError() {
        return percentError;
    }

    public void setPercentError(Float percentError) {
        this.percentError = percentError;
    }

    // Getter for vector as a List<Float>
    public String getVector() {
       return vector;
    }

    // Setter for vector as a List<Float>
   public void setVector(String vector){
        this.vector = vector;
   }

    // Constructors
    public PlanetValues() {
        this.vector = "";
        this.planetName = "Unnamed Planet";
    }

    public PlanetValues(String planetName) {
        this.vector = "";
        this.planetName = planetName;
    }

    public PlanetValues(int unityId, String planetName, String vector, Float percentError) {
        this.unityId = unityId;
        this.planetName = planetName;
        this.setVector(vector);
        this.percentError = percentError;
    }

    public PlanetValues(String planetName, String vector, Float percentError) {
        this.planetName = planetName;
        this.setVector(vector);
        this.percentError = percentError;
    }
}
